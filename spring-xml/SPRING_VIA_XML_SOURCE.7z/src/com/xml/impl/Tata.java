package com.xml.impl;

import com.xml.service.PartsService;

public class Tata implements PartsService {

	@Override
	public void getEngine() {
		System.out.println("BS6 / 1999cc Petrol Tata Engine upgradable" );
	}

	@Override
	public void getCarType() {
		// TODO Auto-generated method stub

	}

}
