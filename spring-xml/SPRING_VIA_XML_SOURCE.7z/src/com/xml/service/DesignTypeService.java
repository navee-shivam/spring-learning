package com.xml.service;

public interface DesignTypeService {
	public void getModelType();
}
