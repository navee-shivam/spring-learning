/**
 *
 */
package com.xml.service;

/**
 * @author navee
 *
 */
public interface PartsService {

	public void getEngine();

	public void getCarType();

}
